const cursosContainer = document.getElementById('cursosContainer');

//GET Request
async function getCourses(){
    let response = await fetch("http://localhost:8080/courses/all");
    let json = await response.json();
    let divContent = "<ol>";
    json.forEach(course => {
        console.log(course);
        divContent += `<li><p>${course.name}</p>
        <small>${course.teacher.name}</small></li>`
    });
    divContent += "</ol>"
    console.log(divContent);
    cursosContainer.innerHTML = divContent;
}

async function postTeacher(){
    //10 segundos
    console.log("POST");
}

getCourses();


