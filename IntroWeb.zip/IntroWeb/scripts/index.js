const emailInput = document.getElementById('emailInput'); //DOMElement
const passwordInput = document.getElementById('passwordInput');
const loginButton = document.getElementById('loginButton');


function signin(){
    let email = emailInput.value;
    let pass = passwordInput.value;
    alert(email + ":" + pass);
}

const signin2 = ()=>{
    let email = emailInput.value;
    let pass = passwordInput.value;
    console.log(email + ":" + pass);
}

loginButton.addEventListener('click', signin2 );
//signin -> Function
//signin() -> Ejecuto la función y el tipo es deacuerdo al tipo de singin

