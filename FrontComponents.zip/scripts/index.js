const cursosContainer = document.getElementById('cursosContainer');

//GET Request
async function getCourses(){
    let response = await fetch("http://localhost:8080/courses/all");
    let json = await response.json();
    console.log(json);
    json.forEach(obj =>{
        console.log(obj);
        let card = new Card(obj).render();
        console.log(card);
        cursosContainer.appendChild(card);
    });
}

async function postTeacher(){
    //10 segundos
    console.log("POST");
}

getCourses();


