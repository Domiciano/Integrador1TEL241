class Card{

    constructor(course){
        this.course = course;
    }

    render(){
        let container = document.createElement('div'); //<div></div>
        container.classList.add("card"); //<div class="card"></div>
        container.classList.add("coursecard");//<div class="card coursecard"></div>

        let img = document.createElement('img');
        img.setAttribute("src", "https://oportunidades.icesi.edu.co/images/espanol/logo.png");
        img.classList.add('card-img-top');
        
        let body = document.createElement('div'); //<div></div>
        body.classList.add('card-body');

        let title = document.createElement('h5'); //<h5></h5>
        title.classList.add('card-title');

        let p = document.createElement('p'); //<p></p>
        p.classList.add('card-text');

        body.appendChild(title);
        body.appendChild(p);
        container.appendChild(img);
        container.appendChild(body);

        //Datos
        p.textContent = this.course.teacher.name;
        title.textContent = this.course.name;
    

        return container;
    }

}